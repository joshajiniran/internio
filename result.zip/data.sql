-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` varchar(0) DEFAULT NULL,
  `name` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` varchar(0) DEFAULT NULL,
  `group_id` varchar(0) DEFAULT NULL,
  `permission_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` tinyint(4) DEFAULT NULL,
  `content_type_id` tinyint(4) DEFAULT NULL,
  `codename` varchar(24) DEFAULT NULL,
  `name` varchar(29) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,1,'add_logentry','Can add log entry'),(2,1,'change_logentry','Can change log entry'),(3,1,'delete_logentry','Can delete log entry'),(4,1,'view_logentry','Can view log entry'),(5,2,'add_permission','Can add permission'),(6,2,'change_permission','Can change permission'),(7,2,'delete_permission','Can delete permission'),(8,2,'view_permission','Can view permission'),(9,3,'add_group','Can add group'),(10,3,'change_group','Can change group'),(11,3,'delete_group','Can delete group'),(12,3,'view_group','Can view group'),(13,4,'add_user','Can add user'),(14,4,'change_user','Can change user'),(15,4,'delete_user','Can delete user'),(16,4,'view_user','Can view user'),(17,5,'add_contenttype','Can add content type'),(18,5,'change_contenttype','Can change content type'),(19,5,'delete_contenttype','Can delete content type'),(20,5,'view_contenttype','Can view content type'),(21,6,'add_session','Can add session'),(22,6,'change_session','Can change session'),(23,6,'delete_session','Can delete session'),(24,6,'view_session','Can view session'),(25,7,'add_contact','Can add contact'),(26,7,'change_contact','Can change contact'),(27,7,'delete_contact','Can delete contact'),(28,7,'view_contact','Can view contact'),(29,8,'add_job','Can add job'),(30,8,'change_job','Can change job'),(31,8,'delete_job','Can delete job'),(32,8,'view_job','Can view job'),(33,9,'add_emailsubscription','Can add email subscription'),(34,9,'change_emailsubscription','Can change email subscription'),(35,9,'delete_emailsubscription','Can delete email subscription'),(36,9,'view_emailsubscription','Can view email subscription'),(37,10,'add_blogpost','Can add blog post'),(38,10,'change_blogpost','Can change blog post'),(39,10,'delete_blogpost','Can delete blog post'),(40,10,'view_blogpost','Can view blog post');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` tinyint(4) DEFAULT NULL,
  `password` varchar(78) DEFAULT NULL,
  `last_login` varchar(10) DEFAULT NULL,
  `is_superuser` tinyint(4) DEFAULT NULL,
  `username` varchar(10) DEFAULT NULL,
  `last_name` varchar(0) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `is_staff` tinyint(4) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `date_joined` varchar(10) DEFAULT NULL,
  `first_name` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$216000$xRag2AleP1wN$2Mv+fXw7Vy1MKWqk6/3J+Xf+MQJBsvGjPU54NhDnrxY=','2020-10-17',1,'propenster','','faitholusegun60@gmail.com',1,1,'2020-10-17','');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` varchar(0) DEFAULT NULL,
  `user_id` varchar(0) DEFAULT NULL,
  `group_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` varchar(0) DEFAULT NULL,
  `user_id` varchar(0) DEFAULT NULL,
  `permission_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` tinyint(4) DEFAULT NULL,
  `action_time` varchar(10) DEFAULT NULL,
  `object_id` tinyint(4) DEFAULT NULL,
  `object_repr` varchar(200) DEFAULT NULL,
  `change_message` varchar(44) DEFAULT NULL,
  `content_type_id` tinyint(4) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `action_flag` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2020-10-17',1,'Profession UI/UX Designer Facebook Inc internship Western TX, U.S. Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attri','[{\"added\": {}}]',8,1,1),(2,'2020-10-17',10,'DevOps Engineer Python Software Foundation Mountain View, CA. ','',8,1,3),(3,'2020-10-18',1,'What is the Meaning of Life?','[{\"added\": {}}]',10,1,1),(4,'2020-10-18',2,'Even the all-powerful Pointing has no control about the blind texts','[{\"added\": {}}]',10,1,1),(5,'2020-10-18',3,'Even the all-powerful Pointing has no control about the blind texts','[{\"added\": {}}]',10,1,1),(6,'2020-10-18',4,'Even the all-powerful Pointing has no control about the blind texts','[{\"added\": {}}]',10,1,1),(7,'2020-10-18',5,'Even the all-powerful Pointing has no control about the blind texts','[{\"added\": {}}]',10,1,1),(8,'2020-10-18',6,'Even the all-powerful Pointing has no control about the blind texts','[{\"added\": {}}]',10,1,1),(9,'2020-10-18',7,'Even the all-powerful Pointing has no control about the blind texts','[{\"added\": {}}]',10,1,1),(10,'2020-10-18',8,'Even the all-powerful Pointing has no control about the blind texts','[{\"added\": {}}]',10,1,1),(11,'2020-10-18',9,'Even the all-powerful Pointing has no control about the blind texts','[{\"added\": {}}]',10,1,1),(12,'2020-10-18',9,'Even the all-powerful Pointing has no control about the blind texts','[{\"changed\": {\"fields\": [\"Slug\"]}}]',10,1,2),(13,'2020-10-18',8,'Even the all-powerful Pointing has no control about the blind texts','',10,1,3),(14,'2020-10-18',7,'Even the all-powerful Pointing has no control about the blind texts','',10,1,3),(15,'2020-10-18',6,'Even the all-powerful Pointing has no control about the blind texts','',10,1,3),(16,'2020-10-18',5,'Even the all-powerful Pointing has no control about the blind texts','',10,1,3),(17,'2020-10-18',4,'Even the all-powerful Pointing has no control about the blind texts','',10,1,3),(18,'2020-10-18',3,'Even the all-powerful Pointing has no control about the blind texts','',10,1,3),(19,'2020-10-18',2,'Even the all-powerful Pointing has no control about the blind texts','',10,1,3),(20,'2020-10-18',1,'What is the Meaning of Life?','[{\"changed\": {\"fields\": [\"Slug\"]}}]',10,1,2),(21,'2020-10-18',10,'When are we coming back?','[{\"added\": {}}]',10,1,1),(22,'2020-10-18',11,'Lorem ipsum dolor sit amet, consectetur adipisicing elit.','[{\"added\": {}}]',10,1,1),(23,'2020-10-18',12,'Welcome to day to tkas tkst astka','[{\"added\": {}}]',10,1,1),(24,'2020-10-18',13,'You may add another blog post below','[{\"added\": {}}]',10,1,1),(25,'2020-10-18',1,'What is the Meaning of Life?','[]',10,1,2),(26,'2020-10-18',9,'Even the all-powerful Pointing has no control about the blind texts','[{\"changed\": {\"fields\": [\"Status\"]}}]',10,1,2),(27,'2020-10-18',10,'When are we coming back?','[{\"changed\": {\"fields\": [\"Feature image\"]}}]',10,1,2),(28,'2020-10-18',1,'What is the Meaning of Life?','[{\"changed\": {\"fields\": [\"Status\"]}}]',10,1,2),(29,'2020-10-18',14,'Quick and efficient processing','[{\"added\": {}}]',10,1,1),(30,'2020-10-18',15,'Your privacy is important to us','[{\"added\": {}}]',10,1,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` tinyint(4) DEFAULT NULL,
  `app_label` varchar(12) DEFAULT NULL,
  `model` varchar(17) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(10,'pages','blogpost'),(7,'pages','contact'),(9,'pages','emailsubscription'),(8,'pages','job'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` tinyint(4) DEFAULT NULL,
  `app` varchar(12) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `applied` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2020-10-17'),(2,'auth','0001_initial','2020-10-17'),(3,'admin','0001_initial','2020-10-17'),(4,'admin','0002_logentry_remove_auto_add','2020-10-17'),(5,'admin','0003_logentry_add_action_flag_choices','2020-10-17'),(6,'contenttypes','0002_remove_content_type_name','2020-10-17'),(7,'auth','0002_alter_permission_name_max_length','2020-10-17'),(8,'auth','0003_alter_user_email_max_length','2020-10-17'),(9,'auth','0004_alter_user_username_opts','2020-10-17'),(10,'auth','0005_alter_user_last_login_null','2020-10-17'),(11,'auth','0006_require_contenttypes_0002','2020-10-17'),(12,'auth','0007_alter_validators_add_error_messages','2020-10-17'),(13,'auth','0008_alter_user_username_max_length','2020-10-17'),(14,'auth','0009_alter_user_last_name_max_length','2020-10-17'),(15,'auth','0010_alter_group_name_max_length','2020-10-17'),(16,'auth','0011_update_proxy_permissions','2020-10-17'),(17,'auth','0012_alter_user_first_name_max_length','2020-10-17'),(18,'sessions','0001_initial','2020-10-17'),(19,'pages','0001_initial','2020-10-17'),(20,'pages','0002_job','2020-10-17'),(21,'pages','0003_contact_date_created','2020-10-17'),(22,'pages','0004_auto_20201018_0047','2020-10-17'),(23,'pages','0005_blogpost','2020-10-18'),(24,'pages','0006_blogpost_feature_image','2020-10-18'),(25,'pages','0007_auto_20201018_1936','2020-10-18');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(32) DEFAULT NULL,
  `session_data` varchar(228) DEFAULT NULL,
  `expire_date` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('3up9qagcyrbdvr9kfn3ko1un1m4z3ej1','.eJxVjEEOwiAQRe_C2pChpTB16d4zNAMzSNVAUtqV8e7apAvd_vfef6mJtjVPW5NlmlmdlVGn3y1QfEjZAd-p3KqOtazLHPSu6IM2fa0sz8vh_h1kavlbDzQiMEiMCQNadl0HBOi9FzCJrDfo-9SDs2CDA4vJMIsfGZ0dTDLq_QHR0TcY:1kTqRO:QuHxWyww7bkRisSK3dU6Y8qXS6MszHlEOk6FMBup8Jw','2020-10-31');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_blogpost`
--

DROP TABLE IF EXISTS `pages_blogpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_blogpost` (
  `id` tinyint(4) DEFAULT NULL,
  `title` varchar(67) DEFAULT NULL,
  `body` varchar(210) DEFAULT NULL,
  `created_on` varchar(0) DEFAULT NULL,
  `comments_count` tinyint(4) DEFAULT NULL,
  `feature_image` varchar(27) DEFAULT NULL,
  `slug` varchar(55) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `author_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_blogpost`
--

LOCK TABLES `pages_blogpost` WRITE;
/*!40000 ALTER TABLE `pages_blogpost` DISABLE KEYS */;
INSERT INTO `pages_blogpost` VALUES (1,'What is the Meaning of Life?','The application should deduct Fidelity Bank’s commission for every successful flight payment transaction according to the amount defined in the contract document.','',5,'gallery/image_8.jpg','what-is-the-meaning-of-life',1,1),(9,'Even the all-powerful Pointing has no control about the blind texts','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor minima, dolores quis, dolorum accusamu','',4,'gallery/image_8_0c4nxwY.jpg','even-the-all-powerful-pointing-has-no-control',1,1),(10,'When are we coming back?','THe andaakasdla lsldka klsd laks kldaskl  klda klsd klas kld sdkld k','',5,'gallery/image_4_eP1BbF9.jpg','when-are-we-coming-back',1,1),(11,'Lorem ipsum dolor sit amet, consectetur adipisicing elit.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias architecto enim non iste maxime optio, ut com','',4,'gallery/image_1_ORBxQTI.jpg','lorem-ipsum-dolor-sit-amet-consectetur-adipisicing-elit',1,1),(12,'Welcome to day to tkas tkst astka','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet nobis natus incidunt officia assumenda.','',12,'gallery/image_2_7Ur84Oi.jpg','welcome-day-tkas-tkst-astka',1,1),(13,'You may add another blog post below','You may add another blog post belowYou may add another blog post belowYou may add another blog post belowYou may add another blog post belowYou may add another blog post belowYou may add another blog post below','',3,'gallery/image_3_EuUyukF.jpg','you-may-add-another-blog-post-below',1,1),(14,'Quick and efficient processing','Directly upload your file into the toolbox above to convert your Microsoft Word document to PDF. The file size does not matter, nor is the need to register.','',18,'gallery/image_5_bzlgdiy.jpg','quick-and-efficient-processing',1,1),(15,'Your privacy is important to us','One hour after the conversion, your files will be deleted from our servers forever. If you want to know more please read our privacy policy below.','',8,'gallery/image_6_o3xMGLn.jpg','your-privacy-important-us',1,1);
/*!40000 ALTER TABLE `pages_blogpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_contact`
--

DROP TABLE IF EXISTS `pages_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_contact` (
  `id` tinyint(4) DEFAULT NULL,
  `name` varchar(14) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `subject` varchar(61) DEFAULT NULL,
  `message` varchar(205) DEFAULT NULL,
  `date_created` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_contact`
--

LOCK TABLES `pages_contact` WRITE;
/*!40000 ALTER TABLE `pages_contact` DISABLE KEYS */;
INSERT INTO `pages_contact` VALUES (1,'Faith Olusegun','faitholusegun60@gmail.com','On Joining your Lab as a Graduate Student and Career Guidance','This is a test..',''),(2,'Faith Olusegun','faitholusegun60@gmail.com','On Joining your Lab as a Graduate Student and Career Guidance','This is a test..',''),(3,'John Doe','johndoe@gmail.com','Please I would like to create a company account','Hi. I am John Doe. I\'ve been trying to create a company account since yesterday but could not get it to work. Could you guys help me?\r\n\r\nAny support will be kindly appreciated.\r\n\r\nThanks.\r\nJohn Haddon Doe.',''),(4,'Adebayo Jesse','a.jesse@kpmg.org.ng','I want to register on this site','Hello,\r\nI am Jesse. I want to register as an internship seeker. How can you help me?\r\n\r\nThank you.',''),(5,'Salvation Musa','salvationarmy@babrosa.com','When are you guys going to fix my router?','We try to make it as easy as possible to convert your DOC files to PDF. You don’t need to adjust any settings and the conversion only takes a few seconds.','');
/*!40000 ALTER TABLE `pages_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_emailsubscription`
--

DROP TABLE IF EXISTS `pages_emailsubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_emailsubscription` (
  `id` varchar(0) DEFAULT NULL,
  `email` varchar(0) DEFAULT NULL,
  `date_subscribed` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_emailsubscription`
--

LOCK TABLES `pages_emailsubscription` WRITE;
/*!40000 ALTER TABLE `pages_emailsubscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages_emailsubscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_job`
--

DROP TABLE IF EXISTS `pages_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_job` (
  `id` tinyint(4) DEFAULT NULL,
  `title` varchar(33) DEFAULT NULL,
  `company` varchar(26) DEFAULT NULL,
  `location` varchar(26) DEFAULT NULL,
  `description` text,
  `date_created` varchar(0) DEFAULT NULL,
  `job_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_job`
--

LOCK TABLES `pages_job` WRITE;
/*!40000 ALTER TABLE `pages_job` DISABLE KEYS */;
INSERT INTO `pages_job` VALUES (1,'Profession UI/UX Designer','Facebook Inc','Western TX, U.S.','Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.\r\n\r\nLorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.\r\n\r\nLorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.\r\n\r\nLorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.','','internship'),(2,'Intern Farm Supervisor','Hendrix Broiler Farm','Wagenigen, the Netherlands','This is a job post for a Wageningen....','','internship'),(3,'Backend Developer','Google Inc.','Mountain View, CA.','This is another job post from Google.\r\nSalary: $500000/year\r\n\r\nSkillset: JAVA, Python, C#, Agile/SCRUM, Machine Learning.','','parttime'),(4,'Open Source Interactive Developer','Adobe','Hittaca, SF.','This is another job post....','','Temporary'),(5,'Frontend Developer','Stackoverflow','Birmingham, UK','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa ad iure porro mollitia architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur.','','Temporary'),(6,'Javascript Developer','Netflix','Mountain View, CA.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit.','','fulltime'),(7,'DevOps Engineer','Python Software Foundation','Mountain View, CA.','architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur','','parttime'),(8,'DevOps Engineer','Python Software Foundation','Mountain View, CA.','architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur','','parttime'),(9,'DevOps Engineer','Python Software Foundation','Mountain View, CA.','architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur','','parttime'),(11,'SASS Software Developer','Workforce Inc.','Cardiff City, UK','\"Microsoft.AspNetCore.Server.Kestrel.Transport.Sockets, {Microsoft.AspNetCore.Server.Kestrel.Transport.Sockets, 2.2.0}\",\r\n      \"Microsoft.AspNetCore.Session, {Microsoft.AspNetCore.Session, 2.2.0}\",\r\n      \"Microsoft.AspNetCore.SignalR, {Microsoft.AspNetCore.SignalR, 1.1.0}\",\r\n      \"Microsoft.AspNetCore.SignalR.Common, {Microsoft.AspNetCore.SignalR.Common, 1.1.0}\",\r\n      \"Microsoft.AspNetCore.SignalR.Core, {Microsoft.AspNetCore.SignalR.Core, 1.1.0}\",\r\n      \"Microsoft.AspNetCore.SignalR.Protocols.Json, {Microsoft.AspNetCore.SignalR.Protocols.Json, 1.1.0}\",\r\n      \"Microsoft.AspNetCore.SpaServices, {Microsoft.AspNetCore.SpaServices, 2.2.0}\",\r\n      \"Microsoft.AspNetCore.SpaServices.Extensions, {Microsoft.AspNetCore.SpaServices.Extensions, 2.2.0}\",\r\n      \"Microsoft.AspNetCore.StaticFiles, {Microsoft.AspNetCore.StaticFiles, 2.2.0}\",\r\n      \"Microsoft.AspNetCore.WebSockets, {Microsoft.AspNetCore.WebSockets, 2.2.0}\",\r\n      \"Microsoft.AspNetCore.WebUtilities, {Microsoft.AspNetCore.WebUtilities, 2.2.0}\",\r\n      \"Microsoft.CodeAnalysis, {Microsoft.CodeAnalysis.Common, 2.8.0}\",\r\n      \"Microsoft.CodeAnalysis.CSharp, {Microsoft.CodeAnalysis.CSharp, 2.8','','freelance'),(12,'Android Developer','Migo Inc','San Marino, NV.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa ad iure porro mollitia architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur','','Temporary'),(13,'Professional Animal Breeder','Lammrak Genetics','Amsterdam, TN.','There is an opening for a Professional Breeder and Geneticist at Lamarak Genetics, Amsterdam, The Netherlands.','','parttime'),(14,'Relationship Manager','Everyone Mns','Hittaca, SF.','orem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa ad iure porro mollitia architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur','','fulltime'),(15,'Bootcamp Director','Lendiela','Cardiff City, UK','QWorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa ad iure porro mollitia architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur','','Temporary'),(16,'Laravel Developer','LiteHost','Lagos, NG.','Lorem ipsum dolor sit amet, consectetur adipisicing e','','internship'),(17,'Laravel Developer','LiteHost','Lagos, NG.','Lorem ipsum dolor sit amet, consectetur adipisicing e','','internship');
/*!40000 ALTER TABLE `pages_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlite_sequence`
--

DROP TABLE IF EXISTS `sqlite_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlite_sequence` (
  `name` varchar(19) DEFAULT NULL,
  `seq` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlite_sequence`
--

LOCK TABLES `sqlite_sequence` WRITE;
/*!40000 ALTER TABLE `sqlite_sequence` DISABLE KEYS */;
INSERT INTO `sqlite_sequence` VALUES ('django_migrations',25),('django_admin_log',30),('django_content_type',10),('auth_permission',40),('auth_group',0),('auth_user',1),('pages_contact',5),('pages_job',17),('pages_blogpost',15);
/*!40000 ALTER TABLE `sqlite_sequence` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-22 15:20:29
